"""Contract tests for the sourced domain templates (mobile_security, networking, trust_chain,
poe_chaos_inoculation).

The templates carry sourced invariants, so the tests check provenance (every invariant is
tagged with a source that the template's docs file defines with a URL), structure
(relationship endpoints exist, concepts are canonical), the pathology-confidence separation
the docs promise, and that the new routing vocabulary leaves every older input where it was.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

from semantic_compiler.core.packet import SemanticPacket
from semantic_compiler.expansion import (
    _DOMAIN_PATTERNS,
    _extract_components,
    _infer_domain,
    decompress,
)
from semantic_compiler.expansion.ontology.medical_ontology import MEDICAL_ONTOLOGY
from semantic_compiler.expansion.registry import get_template, list_domains, load_templates
from semantic_compiler.expansion.schema import validate_domain_template

NEW_DOMAINS = ("mobile_security", "networking", "trust_chain", "poe_chaos_inoculation")
DOCS_DIR = Path(__file__).resolve().parents[2] / "docs"
# Each template's source tags are defined in its own docs file.
DOC_FOR = {
    "mobile_security": DOCS_DIR / "DEEP_SYSTEM_INVARIANTS.md",
    "networking": DOCS_DIR / "DEEP_SYSTEM_INVARIANTS.md",
    "trust_chain": DOCS_DIR / "DEEP_SYSTEM_INVARIANTS.md",
    "poe_chaos_inoculation": DOCS_DIR / "POE_CHAOS_INOCULATION_INVARIANTS.md",
}
TAG = re.compile(r"\[([A-Z0-9-]+)\]")
TRAILING_TAGS = re.compile(r"(?:\[[A-Z0-9-]+\])+$")


def packet(text: str) -> SemanticPacket:
    return SemanticPacket(raw_input=text)


@pytest.fixture(scope="module")
def doc_texts() -> dict[str, str]:
    return {domain: path.read_text() for domain, path in DOC_FOR.items()}


def test_new_domains_are_registered_and_valid():
    assert set(NEW_DOMAINS) <= set(list_domains())
    for domain in NEW_DOMAINS:
        template = get_template(domain)
        assert template.domain == domain
        assert len(template.components) >= 8
        assert len(template.invariants) >= 10
        assert len(template.failure_modes) >= 6
        assert len(template.architecture_patterns) >= 5


def test_new_templates_pass_the_json_schema():
    for domain in NEW_DOMAINS:
        t = get_template(domain)
        data = {
            "domain": t.domain, "version": t.version, "description": t.description,
            "components": t.components, "relationships": t.relationships,
            "invariants": t.invariants, "failure_modes": t.failure_modes,
            "architecture_patterns": t.architecture_patterns,
        }
        assert validate_domain_template(data) == []


def test_every_invariant_ends_with_defined_source_tags(doc_texts):
    assert set(DOC_FOR) == set(NEW_DOMAINS)
    for domain in NEW_DOMAINS:
        doc_text = doc_texts[domain]
        for invariant in get_template(domain).invariants:
            assert TRAILING_TAGS.search(invariant), (domain, invariant)
            for tag in TAG.findall(invariant):
                row = next((line for line in doc_text.splitlines() if line.startswith(f"| `{tag}` |")), None)
                assert row is not None, (domain, tag, f"tag is not defined in {DOC_FOR[domain].name}")
                assert "http" in row, (domain, tag, "source row has no URL")


def test_every_defined_source_tag_is_used_by_its_template(doc_texts):
    # A source row nobody cites is dead provenance; keep the table and the template in step.
    for domain in NEW_DOMAINS:
        used = {tag for inv in get_template(domain).invariants for tag in TAG.findall(inv)}
        defined = set(re.findall(r"^\| `([A-Z0-9-]+)` \|", doc_texts[domain], re.M))
        siblings = {d for d in NEW_DOMAINS if DOC_FOR[d] == DOC_FOR[domain]}
        used_by_siblings = {t for d in siblings for inv in get_template(d).invariants for t in TAG.findall(inv)}
        assert defined == used_by_siblings, (domain, defined ^ used_by_siblings)
        assert used <= defined, (domain, used - defined)


def test_invariants_are_unique_within_a_template():
    for domain in NEW_DOMAINS:
        invariants = get_template(domain).invariants
        assert len(invariants) == len(set(invariants)), domain


def test_trust_chain_is_genuinely_cross_sourced():
    tags = {tag for inv in get_template("trust_chain").invariants for tag in TAG.findall(inv)}
    assert {"AOSP-VB", "KNOX-WP", "RFC4033", "RFC6480"} <= tags


def test_relationships_reference_existing_components_and_names_are_unique():
    for domain in NEW_DOMAINS:
        t = get_template(domain)
        names = [c["name"] for c in t.components]
        assert len(names) == len(set(names)), domain
        for rel in t.relationships:
            assert rel["from"] in names, (domain, rel)
            assert rel["to"] in names, (domain, rel)
            assert rel["from"] != rel["to"], (domain, rel)


def test_every_declared_concept_is_canonical():
    for domain in NEW_DOMAINS:
        t = get_template(domain)
        for comp in t.components:
            if "medical_map" in comp:
                assert comp["medical_map"] in MEDICAL_ONTOLOGY, (domain, comp["name"])
        for item in [*t.failure_modes, *t.architecture_patterns]:
            assert item["medical_map"] in MEDICAL_ONTOLOGY, (domain, item["name"])


def test_component_concepts_never_coincide_with_failure_mode_concepts():
    # detect_pathologies treats a shared concept as direct evidence (0.75). The new templates
    # keep the two sets disjoint so confidence reflects evidence, not authoring coincidence.
    for domain in NEW_DOMAINS:
        t = get_template(domain)
        component_concepts = {c["medical_map"] for c in t.components if "medical_map" in c}
        failure_concepts = {f["medical_map"] for f in t.failure_modes}
        assert not component_concepts & failure_concepts, (domain, component_concepts & failure_concepts)


def test_failure_mode_indicators_are_snake_case_and_nonempty():
    for domain in NEW_DOMAINS:
        for fm in get_template(domain).failure_modes:
            assert fm["indicators"], (domain, fm["name"])
            for indicator in fm["indicators"]:
                assert re.fullmatch(r"[a-z0-9_]+", indicator), (domain, fm["name"], indicator)


@pytest.mark.parametrize(
    "text, expected",
    [
        ("The Android bootloader verifies the kernel signature.", "mobile_security"),
        ("Samsung Knox sets the warranty bit when an unsigned kernel boots.", "mobile_security"),
        ("A TrustZone secure world holds the keystore.", "mobile_security"),
        ("A resolver validates the DNSSEC signature.", "networking"),
        ("The RPKI authorizes which AS may announce a prefix over BGP.", "networking"),
        ("DNS answers travel over UDP.", "networking"),
        ("A chain of trust starts at a hardware root of trust.", "trust_chain"),
        ("The verifier checks the trust anchor before accepting the certificate chain.", "trust_chain"),
        # Specific vocabulary beats the generic computation keywords.
        ("The Android server checks the network.", "mobile_security"),
        ("A Chaos Inoculation character has one life.", "poe_chaos_inoculation"),
        ("Energy shield absorbs damage before life.", "poe_chaos_inoculation"),
        ("Eldritch Battery moves energy shield onto mana.", "poe_chaos_inoculation"),
        ("Ghost Reaver turns life leech into shield.", "poe_chaos_inoculation"),
        # Specific PoE vocabulary beats the generic computation and biology keywords.
        ("An energy shield server is immune to chaos.", "poe_chaos_inoculation"),
    ],
)
def test_specific_vocabulary_routes_to_the_new_domains(text, expected):
    assert _infer_domain(packet(text)) == expected


@pytest.mark.parametrize(
    "text, expected",
    [
        ("A server handles requests.", "computation"),
        ("A firewall blocks the network.", "computation"),
        ("The patient has a heartbeat.", "medical"),
        ("Mitochondria produce ATP in the cell.", "biology"),
        ("The court hears appeals.", "universal_generic"),
        # Whole-word matching: substrings of longer words must not route.
        ("The dnsmasq tool and tcpdump are installed.", "universal_generic"),
        ("The bgpq3 utility builds prefix lists.", "universal_generic"),
        # PoE shorthand that describes a computation build must not be pulled into the PoE
        # defense template: bare "path of exile" is deliberately not a routing keyword.
        ("A Path of Exile build with Ice Nova and Hatred.", "universal_generic"),
        ("The shield server handles requests.", "computation"),
        ("The energy shielding tape is installed.", "universal_generic"),
    ],
)
def test_existing_routing_and_word_boundaries_are_unchanged(text, expected):
    assert _infer_domain(packet(text)) == expected


def test_gem_decode_poe_build_spec_still_routes_as_before():
    from scripts.decode_build_demo import POE_NATIVE_SPEC

    assert _infer_domain(packet(POE_NATIVE_SPEC)) == "universal_generic"


def test_new_vocabulary_does_not_move_any_preexisting_calibration_sample():
    from scripts.build_decompression_calibration import SAMPLES

    legacy = [(d, p) for d, p in _DOMAIN_PATTERNS if d not in NEW_DOMAINS]
    assert [d for d, _ in legacy] == ["computation", "biology", "medical"]

    def legacy_infer(text: str) -> str:
        for domain, pattern in legacy:
            if pattern.search(text.lower()):
                return domain
        return "universal_generic"

    moved = [
        (text, legacy_infer(text), _infer_domain(packet(text)))
        for text, intended, _category in SAMPLES
        if intended not in NEW_DOMAINS and legacy_infer(text) != _infer_domain(packet(text))
    ]
    assert moved == []


@pytest.mark.parametrize("domain", NEW_DOMAINS)
def test_decompress_produces_a_valid_model_with_template_concepts(domain):
    sample = {
        "mobile_security": "The Android bootloader verifies the kernel signature.",
        "networking": "A resolver validates the DNSSEC signature.",
        "trust_chain": "A chain of trust from a hardware root.",
        "poe_chaos_inoculation": "Chaos Inoculation sets life to one and leaves energy shield as the only buffer.",
    }[domain]
    model = decompress(packet(sample))
    assert model["domain"] == domain
    template = get_template(domain)
    declared = {c["name"]: c.get("medical_map") for c in template.components}
    by_name = {c["name"]: c for c in model["components"]}
    assert set(by_name) == set(declared)
    for name, concept in declared.items():
        expected = concept if concept in MEDICAL_ONTOLOGY else "unknown"
        assert by_name[name]["medical_map"] == expected, (domain, name)
    # No failure mode is "directly" evidenced merely by the template describing itself.
    assert all(d["confidence"] < 0.75 for d in model["pathology_profile"]["medical_diagnoses"])


def test_component_medical_map_falls_back_when_not_canonical():
    class FakeTemplate:
        components = [
            {"name": "input_layer", "function": "x", "criticality": "high", "medical_map": "not_a_concept"},
            {"name": "mystery", "function": "y", "criticality": "low", "medical_map": "quarantine"},
            {"name": "plain", "function": "z", "criticality": "low"},
        ]

    maps = {c["name"]: c["medical_map"] for c in _extract_components(packet("x"), FakeTemplate())}
    assert maps == {"input_layer": "immune_boundary", "mystery": "quarantine", "plain": "unknown"}


def test_older_templates_are_untouched_by_the_optional_field():
    templates = load_templates()
    for domain, template in templates.items():
        if domain in NEW_DOMAINS:
            continue
        assert not any("medical_map" in c for c in template.components), domain


# --- poe_chaos_inoculation: the version and numbers guardrail -------------------------------

POE = "poe_chaos_inoculation"


def test_poe_invariants_name_a_game_version():
    # The description promises that every invariant says which game version it was sourced for.
    for invariant in get_template(POE).invariants:
        assert re.search(r"PoE 1|PoE 2", invariant), invariant
    joined = " ".join(get_template(POE).invariants)
    assert "PoE 1" in joined and "PoE 2" in joined


def test_poe_invariants_do_not_pin_patch_dependent_numbers():
    # Delay, rate and percentage values change by patch; only the structure is an invariant.
    for invariant in get_template(POE).invariants:
        assert not re.search(r"\d\s*(%|seconds?\b)|per second", invariant), invariant


def test_poe_template_states_that_it_preserves_structure_not_numbers():
    description = get_template(POE).description
    assert "not their numbers" in description
    assert "designed game rules" in description


def test_poe_keystone_trade_and_buffer_are_present_as_components_and_invariants():
    template = get_template(POE)
    names = {c["name"] for c in template.components}
    assert {"chaos_inoculation_keystone", "lethal_pool", "energy_shield_pool", "chaos_immunity",
            "damage_ordering_rule", "recharge_regulator"} <= names
    joined = " ".join(template.invariants).lower()
    for phrase in ("maximum life becomes 1", "immune to chaos damage", "energy shield first",
                   "interrupts it", "no effect on a chaos-immune character"):
        assert phrase in joined, phrase


def test_poe_doc_states_the_guardrail_and_the_limits():
    text = DOC_FOR[POE].read_text()
    for heading in ("## Structure versus literal mechanics (the guardrail)",
                    "### What transfers to other systems, and what does not",
                    "## What was not read or not established"):
        assert heading in text, heading


def test_poe_composite_failure_mode_names_its_parts():
    modes = {fm["name"]: fm for fm in get_template(POE).failure_modes}
    composite = modes["spike_after_chip"]
    assert "recharge_starvation" in composite["description"]
    assert "oversized_hit_overflow" in composite["description"]
    assert {"recharge_starvation", "oversized_hit_overflow"} <= set(modes)


def test_poe_refill_is_stated_in_terms_of_quiet_time():
    template = get_template(POE)
    regulator = next(c for c in template.components if c["name"] == "recharge_regulator")
    assert "quiet time" in regulator["function"] and "gaps between hits" in regulator["function"]
    patterns = {p["name"]: p["description"] for p in template.architecture_patterns}
    assert "quiet-time requirement" in patterns["convert_recovery_into_buffer"]
    assert "constant" in patterns["audit_predicates_on_fixed_value"]
