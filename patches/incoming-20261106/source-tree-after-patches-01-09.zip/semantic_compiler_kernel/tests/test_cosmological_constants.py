"""Tests for the cosmological constants registry.

The module had no tests and no callers before the 2026-11 review.
"""

from __future__ import annotations

import dataclasses
import math
import unittest

from semantic_compiler.registry.cosmological_constants import (
    CONSTANT_PROVENANCE,
    COSMOS,
    KNOWN_DISCREPANCIES,
    CosmologicalConstants,
    check_constant_consistency,
    check_equilibrium_approach,
    compute_bh_core_radius,
    compute_information_amplification,
    compute_psi_equilibrium_gauge,
    compute_quantum_error_floor,
    get_cosmological_isomorphism,
    lambert_w0,
    verify_lambda_trinity,
)


class ProvenanceTests(unittest.TestCase):
    def test_every_constant_has_a_provenance_label(self) -> None:
        fields = {field.name for field in dataclasses.fields(CosmologicalConstants)}
        self.assertEqual(fields, set(CONSTANT_PROVENANCE))

    def test_provenance_labels_are_from_the_closed_set(self) -> None:
        allowed = {"OBSERVED", "DERIVED", "MODEL_PARAMETER", "PREDICTION", "CONSTANT", "MODEL_STATEMENT"}
        self.assertLessEqual(set(CONSTANT_PROVENANCE.values()), allowed)


class ConsistencyContractTests(unittest.TestCase):
    def test_failures_are_exactly_the_documented_discrepancies(self) -> None:
        # A new, unexplained inconsistency fails here; so does a documented one
        # that has since been resolved (its KNOWN_DISCREPANCIES entry is stale).
        failed = {check["id"] for check in check_constant_consistency() if not check["passed"]}
        self.assertEqual(failed, set(KNOWN_DISCREPANCIES))

    def test_foundational_identities_hold(self) -> None:
        passed = {check["id"] for check in check_constant_consistency() if check["passed"]}
        for check_id in (
            "rs_equals_c_over_H0",
            "hubble_radius_equals_schwarzschild",
            "H0_matches_70_km_s_Mpc",
            "lambda_decomposition_sums",
            "saturation_components_sum",
            "saturation_geometric_from_kappa",
            "holographic_bound",
            "lambda_faces_agree",
            "amplification_exponent_matches_cmb",
        ):
            self.assertIn(check_id, passed)

    def test_check_detects_a_perturbed_constant(self) -> None:
        broken = dataclasses.replace(COSMOS, schwarzschild_radius_m=2.0e26)
        failed = {check["id"] for check in check_constant_consistency(broken) if not check["passed"]}
        self.assertIn("rs_equals_c_over_H0", failed)
        self.assertIn("hubble_radius_equals_schwarzschild", failed)

    def test_trinity_reports_the_open_discrepancy_instead_of_asserting_success(self) -> None:
        result = verify_lambda_trinity()
        self.assertTrue(result["converged"])  # decomposition sums to the stored total
        self.assertTrue(result["faces_agree"])
        self.assertFalse(result["faces_match_observed"])
        self.assertAlmostEqual(result["equation_to_observed_ratio"], 1.558, places=2)
        self.assertEqual(result["open_discrepancy"], KNOWN_DISCREPANCIES["lambda_faces_match_observed"])


class LambertTests(unittest.TestCase):
    def test_known_values(self) -> None:
        self.assertEqual(lambert_w0(0.0), 0.0)
        self.assertAlmostEqual(lambert_w0(math.e), 1.0, places=12)
        self.assertAlmostEqual(lambert_w0(1.0), 0.5671432904097838, places=12)  # omega constant
        self.assertAlmostEqual(lambert_w0(-0.2), -0.2591711018190738, places=12)
        self.assertEqual(lambert_w0(-1.0 / math.e), -1.0)

    def test_round_trip_across_the_range(self) -> None:
        for x in (-0.36, -0.3, -0.1, 1e-12, 0.5, 2.0, 2.9, 3.1, 50.0, 1e10, 9.14e37, 1e300):
            w = lambert_w0(x)
            self.assertAlmostEqual(w * math.exp(w) / x, 1.0, places=9, msg=str(x))

    def test_domain_errors(self) -> None:
        for bad in (-0.4, math.nan, math.inf, -math.inf):
            with self.assertRaises(ValueError, msg=str(bad)):
                lambert_w0(bad)


class ComputationTests(unittest.TestCase):
    def test_bh_core_radius_solar_mass(self) -> None:
        result = compute_bh_core_radius(1.0)
        self.assertAlmostEqual(result["lambert_w_value"], 82.99, places=2)
        self.assertAlmostEqual(result["r_core_meters"], 1.34e-33, delta=0.01e-33)

    def test_bh_core_radius_small_mass_uses_true_w(self) -> None:
        # The old asymptotic form returned the mass ratio itself below e.
        result = compute_bh_core_radius(1e-38)
        ratio = result["mass_ratio_M_BH_over_M_P"]
        w = result["lambert_w_value"]
        self.assertAlmostEqual(w * math.exp(w), ratio, delta=0.02)
        self.assertLess(w, ratio)

    def test_bh_core_radius_rejects_non_positive_mass(self) -> None:
        for bad in (0, -1.0, math.nan):
            with self.assertRaises(ValueError):
                compute_bh_core_radius(bad)

    def test_amplification_exposes_the_exponent_mismatch(self) -> None:
        result = compute_information_amplification()
        self.assertAlmostEqual(result["exponent"], 72.81, places=2)
        self.assertAlmostEqual(result["exponent_required_for_cmb"], 69.26, places=2)
        self.assertFalse(result["consistent_with_cmb"])
        self.assertGreater(result["cmb_predicted_K"], 90.0)

    def test_amplification_consistent_when_exponent_matches(self) -> None:
        xi = math.log(COSMOS.cmb_temperature_K / COSMOS.hawking_temperature_K) / (0.91 * 1.143)
        result = compute_information_amplification(0.91, xi, 1.143)
        self.assertTrue(result["consistent_with_cmb"])
        self.assertAlmostEqual(result["cmb_predicted_K"], COSMOS.cmb_temperature_K, delta=0.05)

    def test_amplification_overflow_is_a_float_not_a_string(self) -> None:
        result = compute_information_amplification(1.0, 700.0, 1.0)
        self.assertEqual(result["cmb_predicted_K"], math.inf)
        self.assertEqual(result["amplification_factor"], math.inf)

    def test_quantum_error_floor(self) -> None:
        result = compute_quantum_error_floor(1000)
        self.assertAlmostEqual(result["epsilon_min"], 9.1e-38, delta=1e-40)
        for kwargs in ({"n_qubits": 0}, {"n_qubits": 5, "i_available": 0.0}, {"n_qubits": 5, "C": -1.0}):
            with self.assertRaises(ValueError):
                compute_quantum_error_floor(**kwargs)

    def test_equilibrium_approach_validates_input(self) -> None:
        self.assertEqual(check_equilibrium_approach(0.91)["status"], "APPROACHING")
        for bad in (math.nan, -0.1):
            with self.assertRaises(ValueError):
                check_equilibrium_approach(bad)

    def test_psi_cancellation_is_not_equilibrium(self) -> None:
        result = compute_psi_equilibrium_gauge(
            entropy_production_rate=-5.0, information_flux=5.0, remaining_capacity=0.0
        )
        self.assertEqual(result["psi"], 0.0)
        self.assertFalse(result["at_equilibrium"])
        self.assertEqual(result["status"], "ACTIVE (Ψ > 0, C < 1)")

    def test_psi_default_and_zero(self) -> None:
        self.assertTrue(compute_psi_equilibrium_gauge(remaining_capacity=0.0)["at_equilibrium"])
        self.assertEqual(compute_psi_equilibrium_gauge()["status"], "APPROACHING (Ψ → 0)")
        with self.assertRaises(ValueError):
            compute_psi_equilibrium_gauge(information_flux=math.nan)


class IsomorphismLookupTests(unittest.TestCase):
    def test_exact_and_substring_lookup(self) -> None:
        self.assertEqual(
            get_cosmological_isomorphism("information saturation", "cosmos", "llm")["concept"],
            "information_saturation",
        )
        self.assertEqual(
            get_cosmological_isomorphism("dark energy", "cosmos", "computer")["concept"],
            "dark_energy_rendering_overhead",
        )

    def test_empty_and_tiny_concepts_do_not_match_the_first_entry(self) -> None:
        for concept in ("", " ", "a", "in"):
            result = get_cosmological_isomorphism(concept, "cosmos", "computer")
            self.assertEqual(result["mapping_class"], "UNMAPPED", repr(concept))


if __name__ == "__main__":
    unittest.main()
