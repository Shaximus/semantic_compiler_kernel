"""AUTO mode must read the claim-type key the extractor actually writes."""

from __future__ import annotations

import unittest

from semantic_compiler.core.packet import SemanticPacket
from semantic_compiler.core.pipeline import compile_semantic_packet, resolve_mode
from semantic_compiler.core.types import CompilerMode


def _packet(*claim_types: str) -> SemanticPacket:
    return SemanticPacket(raw_input="x", claim_types=[{"claim_type": name} for name in claim_types])


class ResolveModeTests(unittest.TestCase):
    def test_auto_detects_each_claim_type(self) -> None:
        cases = {
            "REALITY_ORIENTATION": CompilerMode.REGULATED_REALITY_ORIENTATION,
            "FRACTAL_ISOMORPHISM": CompilerMode.FRACTAL_ISOMORPHISM_MAPPING,
            "COSMOLOGICAL_CLAIM": CompilerMode.COSMOLOGICAL_MAPPING,
            "POLICY_CLAIM": CompilerMode.PUBLIC_TRANSLATION,
            "NORMATIVE_PROPOSAL": CompilerMode.PUBLIC_TRANSLATION,
            "AUTHORITY_REQUEST": CompilerMode.APPROVAL_RISK_TRANSLATION,
        }
        for claim, mode in cases.items():
            self.assertEqual(resolve_mode(_packet(claim)), mode, claim)

    def test_precedence_and_default(self) -> None:
        self.assertEqual(
            resolve_mode(_packet("AUTHORITY_REQUEST", "COSMOLOGICAL_CLAIM")),
            CompilerMode.COSMOLOGICAL_MAPPING,
        )
        self.assertEqual(resolve_mode(_packet("OBSERVATION")), CompilerMode.UNIVERSAL_DECOMPRESSION)
        self.assertEqual(resolve_mode(_packet()), CompilerMode.UNIVERSAL_DECOMPRESSION)

    def test_explicit_mode_wins_over_detection(self) -> None:
        self.assertEqual(
            resolve_mode(_packet("COSMOLOGICAL_CLAIM"), requested_mode="SYSTEM_DIAGNOSTIC"),
            CompilerMode.SYSTEM_DIAGNOSTIC,
        )

    def test_unknown_requested_mode_falls_back_to_detection(self) -> None:
        self.assertEqual(
            resolve_mode(_packet("COSMOLOGICAL_CLAIM"), requested_mode="NOT_A_MODE"),
            CompilerMode.COSMOLOGICAL_MAPPING,
        )

    def test_end_to_end_cosmological_sentence_selects_cosmological_mapping(self) -> None:
        packet = compile_semantic_packet(
            "The universe's cosmological constant reflects information saturation at the horizon."
        )
        names = [c.get("claim_type") for c in packet.claim_types]
        self.assertIn("COSMOLOGICAL_CLAIM", names)
        self.assertEqual(packet.mode, CompilerMode.COSMOLOGICAL_MAPPING)


if __name__ == "__main__":
    unittest.main()
