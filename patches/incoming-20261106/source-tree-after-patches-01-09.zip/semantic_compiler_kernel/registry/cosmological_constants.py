"""
Reflexion Semantic Compiler v2.0.0 — Cosmological Constants Registry

The physics backbone of the compiler. These are not metaphors.
These values are taken from the papers below. CONSTANT_PROVENANCE says which
are observational inputs, which are model parameters or derived quantities, and
which are predictions; check_constant_consistency() recomputes what can be
recomputed, and KNOWN_DISCREPANCIES lists the places where the stored numbers
do not close against one another.

Source: "The Λ Trinity: Geometry, Dynamics, and Thermodynamics at the Hubble Horizon"
        Curtis Kingsley & Derek C. Frangos, September 2025

Source: "A Black Hole Cosmological Model with Age Gradient:
         Addressing JWST Anomalies, the Hubble Tension, and Cosmic Acceleration"
        Curtis Kingsley & Derek C. Frangos, August 2025

These constants anchor the compiler's cosmological scale layer.
When the compiler maps concepts to the cosmic scale, it uses THESE numbers,
not vague metaphors about "the universe being big."

Citation: Lambda Trinity — The Three Faces of Lambda
Citation: BH Universe Paper — Section 2 (Theoretical Framework)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import math


# ═══════════════════════════════════════════════════════════════════
# FUNDAMENTAL COSMOLOGICAL CONSTANTS
# From: Curtis Kingsley & Derek C. Frangos (2025)
# ═══════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class CosmologicalConstants:
    """
    Verified cosmological constants from the Black Hole Universe framework.
    All values are derived from first principles in the published papers.
    """

    # ── The Foundational Identity ──
    # rs = rh = c/H0: The Schwarzschild radius of the universe equals
    # the Hubble radius. This is not a coincidence. This is the cornerstone.
    schwarzschild_radius_m: float = 1.32e26        # meters
    hubble_radius_m: float = 1.32e26               # meters (same value — the identity)
    hubble_constant_si: float = 2.27e-18           # H0 in s^-1 (≈ 70 km/s/Mpc)

    # ── The Cosmological Constant ──
    lambda_observed: float = 1.105e-52             # m^-2 (total observed)
    lambda_geometric: float = 8.589e-53            # m^-2 (78% — spacetime curvature)
    lambda_information: float = 2.461e-53          # m^-2 (22% — information saturation)
    geometric_fraction: float = 0.78               # 78%
    information_fraction: float = 0.22             # 22%

    # ── Information Saturation ──
    # C = I_total / I_max = 0.91
    # The universe is at 91% information capacity.
    # Decomposition: C = C_geom + C_info = 0.777 + 0.133
    # C_geom = 1 - e^(-3κ̃) = 1 - e^(-1.5) ≈ 0.777 (from pure LTB geometry)
    # C_info = 0.133 (from vacuum entanglement / quantum field effects)
    # Verified by 12 independent methods: weighted mean 0.915 ± 0.030
    information_saturation_C: float = 0.91
    information_saturation_C_geom: float = 0.777    # Geometric component
    information_saturation_C_info: float = 0.133    # Information component
    amplification_factor_Xi: float = 70.0          # Ξ(C) effective amplification
    information_field_I_r: float = 1.143           # I[r] at quantum extremal surface

    # ── The Kingsley Curve: κ̃ = 0.5 (Master Parameter) ──
    # Dimensionless curvature: κ̃ = κ·R_H² = 0.5
    # Physical: κ = H₀²/c² ≈ 0.050 Gpc⁻²
    # Determines: geometric dark energy (3κ̃ = 1.5), age gradient steepness,
    #             geometric saturation baseline (1 - e^(-3κ̃))
    # NOT free: uniquely determined by Λ_obs = Λ_geom(κ̃) + Λ_info(C(κ̃))
    kappa_tilde: float = 0.5
    kappa_physical_gpc2: float = 0.050

    # ── Holographic Bound (Maximum Information) ──
    # I_max = π·r_H² / (ℓ_p²·ln(2)) = 3.04 × 10¹²² bits
    # This is the universe's TOTAL ADDRESSABLE STORAGE.
    information_max_bits: float = 3.04e122
    standard_model_dof: float = 106.75             # N_fields (SM degrees of freedom)

    # ── Temperatures ──
    # T_CMB = T_H × exp(C × Ξ(C) × I[r])
    # The CMB IS Hawking radiation, amplified by information saturation
    cmb_temperature_K: float = 2.725               # K (observed)
    hawking_temperature_K: float = 2.269e-30       # K (Gibbons-Hawking)
    amplification_exponent: float = 69.0           # C × Ξ(C) × I[r] ≈ 69

    # ── The Redshift Drift Prediction ──
    # ż = -1.23 × 10^-10 yr^-1 at z = 1
    # OPPOSITE IN SIGN to ΛCDM's positive drift
    # Binary test. Falsifiable by 2035 (ELT/ANDES).
    redshift_drift_z1: float = -1.23e-10           # yr^-1

    # ── The Void State ──
    # At C = 1.0, universe fragments into ~10¹²² Planck-scale black holes
    # Each potentially seeds a new universe. The loop closes.
    planck_scale_bh_count: float = 1e122           # number of seed black holes
    planck_length_m: float = 1.616e-35             # meters

    # ── The 5% Offset ──
    # Earth is at r ≈ 0.05 × R_H from the cosmic center
    # NOT a violation of Copernican principle — holographic encoding
    # makes EVERY location appear 5% from center
    observer_offset_fraction: float = 0.05

    # ── De Sitter Equilibrium ──
    # When N_sur = N_bulk: expansion stops. Loop closes.
    # dV/dt = 0 → H = constant → information equilibrium
    equilibrium_condition: str = "N_sur = N_bulk"

    # ── TWO-PARAMETER SYSTEM ──
    # The entire universe is determined by TWO numbers:
    #   κ̃ = 0.5 (geometry)
    #   C = 0.91 (information)
    # Everything else follows. Two axioms. Total coherence.
    system_parameter_count: int = 2


# Singleton instance
COSMOS = CosmologicalConstants()


# Where each stored value comes from. "Measured" in the old module docstring was
# true of the OBSERVED rows only.
CONSTANT_PROVENANCE: dict[str, str] = {
    "schwarzschild_radius_m": "DERIVED",        # c / H0
    "hubble_radius_m": "DERIVED",               # c / H0
    "hubble_constant_si": "OBSERVED",
    "lambda_observed": "OBSERVED",
    "lambda_geometric": "MODEL_PARAMETER",      # K&F decomposition of the observed value
    "lambda_information": "MODEL_PARAMETER",
    "geometric_fraction": "MODEL_PARAMETER",
    "information_fraction": "MODEL_PARAMETER",
    "information_saturation_C": "MODEL_PARAMETER",
    "information_saturation_C_geom": "DERIVED",  # 1 - exp(-3 kappa_tilde)
    "information_saturation_C_info": "MODEL_PARAMETER",
    "amplification_factor_Xi": "MODEL_PARAMETER",
    "information_field_I_r": "MODEL_PARAMETER",
    "kappa_tilde": "MODEL_PARAMETER",
    "kappa_physical_gpc2": "DERIVED",           # H0^2 / c^2
    "information_max_bits": "DERIVED",          # holographic bound
    "standard_model_dof": "OBSERVED",
    "cmb_temperature_K": "OBSERVED",
    "hawking_temperature_K": "DERIVED",
    "amplification_exponent": "DERIVED",
    "redshift_drift_z1": "PREDICTION",
    "planck_scale_bh_count": "MODEL_PARAMETER",
    "planck_length_m": "CONSTANT",
    "observer_offset_fraction": "MODEL_PARAMETER",
    "equilibrium_condition": "MODEL_STATEMENT",
    "system_parameter_count": "MODEL_STATEMENT",
}


# ═══════════════════════════════════════════════════════════════════
# THE THREE FACES OF LAMBDA (The Λ Trinity)
#
# These are not three different things.
# They are the SAME phenomenon viewed through THREE lenses.
#
# Geometric:     Λ = R/4 = 3/L²       (curvature of de Sitter spacetime)
# Dynamical:     Λ = 3H²/c²           (expansion rate of cosmic horizon)
# Thermodynamic: Λ = 3πk_B/(S·L²_P)   (information capacity of universe)
#
# "These are not merely related — they are the same phenomenon
#  viewed through different mathematical lenses."
# ═══════════════════════════════════════════════════════════════════

LAMBDA_TRINITY: dict[str, dict[str, Any]] = {
    "geometric": {
        "face": "Geometric Curvature",
        "equation": "Λ = R/4 = 3/L²",
        "description": "The intrinsic curvature of de Sitter spacetime",
        "contribution": 0.78,
        "value": COSMOS.lambda_geometric,
        "insight": (
            "De Sitter spacetime has intrinsic curvature. "
            "The cosmological constant IS that curvature scale."
        ),
    },
    "dynamical": {
        "face": "Dynamical Expansion",
        "equation": "Λ = 3H²/c²",
        "description": "The expansion rate of the cosmic horizon",
        "contribution": 1.0,  # The full value via Friedmann
        "value": COSMOS.lambda_observed,
        "insight": (
            "The Hubble radius in de Sitter space exactly matches "
            "the geometric horizon radius L. Expansion dynamics "
            "and spacetime geometry are the same thing."
        ),
    },
    "thermodynamic": {
        "face": "Thermodynamic Information",
        "equation": "Λ = 3πk_B/(S·L²_P)",
        "description": "The information capacity of the universe",
        "contribution": 0.22,
        "value": COSMOS.lambda_information,
        "insight": (
            "The cosmological constant encodes the information "
            "capacity of the universe. Dark energy is the universe "
            "approaching information equilibrium."
        ),
    },
}


# ═══════════════════════════════════════════════════════════════════
# COSMOLOGICAL-TO-COMPUTATIONAL ISOMORPHISMS
#
# These are the fractal mappings between the cosmic scale and
# the computational/informational scale. Not metaphors.
# Structural identities grounded in the physics.
# ═══════════════════════════════════════════════════════════════════

COSMOS_COMPUTATION_MAP: dict[str, dict[str, str]] = {
    "information_saturation": {
        "cosmos": "C = 0.91. Universe at 91% information capacity.",
        "computer": "Storage at 91% capacity. Performance degradation begins.",
        "human": "Cognitive load at 91%. Working memory nearly full.",
        "llm": "Context window at 91%. Attention starting to drop older tokens.",
        "structural_law": (
            "Any information-processing system approaching capacity "
            "exhibits acceleration toward equilibrium. "
            "This is dark energy at cosmic scale, GC pressure at "
            "compute scale, stress at human scale."
        ),
    },
    "hawking_radiation_data_loss": {
        "cosmos": "Hawking radiation: information escaping black holes.",
        "computer": "Data loss: information escaping storage (bit rot, corruption).",
        "human": "Forgetting: information escaping long-term memory.",
        "llm": "Context eviction: information escaping attention window.",
        "structural_law": (
            "Information always leaks from any finite storage system. "
            "The leak rate is inversely proportional to the storage capacity. "
            "Small black holes evaporate faster. Small context windows forget faster."
        ),
    },
    "dark_energy_rendering_overhead": {
        "cosmos": "Dark energy: 78% geometric + 22% informational. Drives expansion.",
        "computer": "System overhead: OS processes + GC + swap. Drives memory growth.",
        "human": "Homeostasis: unconscious processing + metabolic maintenance.",
        "llm": "Inference overhead: KV cache + attention compute + safety filtering.",
        "structural_law": (
            "Every information-processing system has an irreducible overhead "
            "that accelerates as the system approaches capacity. "
            "The 78/22 split may be universal: 78% structural overhead, "
            "22% information-processing overhead."
        ),
    },
    "holographic_principle": {
        "cosmos": "All information encoded on 2D boundary (event horizon).",
        "computer": "All data encoded on 2D surfaces (disk platters, NAND layers).",
        "human": "All experience encoded on 2D cortical surface (brain wrinkles).",
        "llm": "All knowledge encoded in 2D weight matrices (transformer layers).",
        "structural_law": (
            "Information storage is fundamentally 2D. "
            "The 3D 'interior' is always a reconstruction from boundary data. "
            "This is why 'everything is flat' — cosmic flatness, disk surfaces, "
            "cortical folds, weight matrices."
        ),
    },
    "equilibrium_heat_death_vs_loop": {
        "cosmos": "N_sur = N_bulk → expansion stops → stable loop, NOT heat death.",
        "computer": "Load balanced → system stable → runs forever if powered.",
        "human": "Homeostasis achieved → body stable → lives (until hardware fails).",
        "llm": "Training converged → loss stable → model is 'done' learning.",
        "structural_law": (
            "Equilibrium is NOT death. It is the stable loop. "
            "Infinity is a stable loop, not a line. "
            "The universe doesn't die — it reaches equipartition and persists. "
            "All complexity is binary wearing costumes."
        ),
    },
    "cmb_as_amplified_noise": {
        "cosmos": "CMB = Hawking radiation × e^69. Background noise amplified by saturation.",
        "computer": "Thermal noise amplified by load. Fan speed = invisible workload.",
        "human": "Tinnitus: neural noise amplified by fatigue/saturation.",
        "llm": "Hallucination: pattern noise amplified by low-confidence regions.",
        "structural_law": (
            "Background noise in any saturated system gets amplified. "
            "The amplification factor depends on how full the system is. "
            "At C = 0.91, the amplification is e^69 ≈ 10^30."
        ),
    },
    "age_gradient": {
        "cosmos": "Peripheral regions older than central. 3.8 Gyr vs 0.48 Gyr at z=10.",
        "computer": "Edge nodes process longer than central coordinator.",
        "human": "Peripheral nervous system develops before central cortex.",
        "llm": "Early layers process longer (first attention heads see everything).",
        "structural_law": (
            "In any system with a center and a boundary, the boundary "
            "has experienced more processing time than the center. "
            "This is why JWST sees 'impossible' mature galaxies at high z — "
            "they had more time than the standard model predicted."
        ),
    },
    "schwarzschild_hubble_identity": {
        "cosmos": "rs = rh = c/H0. The black hole boundary IS the cosmic horizon.",
        "computer": "System boundary IS the network boundary. There is no 'outside'.",
        "human": "Perception boundary IS the consciousness boundary. There is no 'outside' mind.",
        "llm": "Context window IS the knowledge boundary. There is no 'outside' the window.",
        "structural_law": (
            "The storage boundary and the experience boundary are the same thing. "
            "There is no 'outside'. The container IS the content. "
            "This is the foundational identity. Everything else follows from this."
        ),
    },
    "decoherence_as_throughput": {
        "cosmos": (
            "Γ_decoherence = (k_BT/ℏ) × [C/(1-C)] × [I_local/I_avail] × W₀(N/N_avail). "
            "At C=0.91: system-wide load factor = 10.1×."
        ),
        "computer": (
            "Throughput = base_clock × load_factor × memory_pressure × scheduler_overhead. "
            "At 91% utilization: load factor ≈ 10× (queueing theory)."
        ),
        "human": (
            "Processing speed = metabolic_rate × cognitive_load × working_memory_pressure × attention_scheduling. "
            "Near capacity: everything slows except the most urgent task."
        ),
        "llm": (
            "Inference throughput = FLOPS × batch_utilization × KV_cache_pressure × attention_scheduling. "
            "Near context limit: generation quality degrades."
        ),
        "structural_law": (
            "Every information-processing system has a throughput equation with "
            "FOUR factors: base rate, global load, local pressure, scheduler overhead. "
            "The Lambert W function (W₀) appears universally as the saturation regulator. "
            "W₀(1) = 0.567 → graceful degradation, not crash. "
            "This replaces renormalization: bounded behavior from capacity constraints."
        ),
    },
    "two_parameter_system": {
        "cosmos": "κ̃ = 0.5 (geometry) + C = 0.91 (information). Two numbers. Everything follows.",
        "computer": "Architecture (ISA) + workload (utilization). Two parameters define system behavior.",
        "human": "Genetics (structure) + environment (information). Nature + nurture. Two parameters.",
        "llm": "Architecture (layers/heads) + training data (information). Two parameters define capability.",
        "structural_law": (
            "Every system of sufficient complexity can be characterized by "
            "TWO master parameters: a structural parameter (geometry/architecture) "
            "and an information parameter (saturation/utilization). "
            "The Kingsley Curve (κ̃ = 0.5) is the geometry. C = 0.91 is the information. "
            "When your axioms are correct, TWO numbers generate EVERYTHING."
        ),
    },
    "scale_hierarchy": {
        "cosmos": (
            "Planck: 1 bit → Atomic: 10^75 bits → Lab: 10^60 bits → "
            "Planetary: 10^80 bits → Galactic: 10^80 bits → Cosmic: 10^122 bits."
        ),
        "computer": (
            "Register: 64 bits → Cache: 10^6 bits → RAM: 10^11 bits → "
            "SSD: 10^13 bits → Datacenter: 10^19 bits → Internet: 10^22 bits."
        ),
        "human": (
            "Synapse: 1 bit → Neuron: 10^3 bits → Column: 10^6 bits → "
            "Region: 10^9 bits → Brain: 10^15 bits → Civilization: 10^20 bits."
        ),
        "llm": (
            "Weight: 16 bits → Layer: 10^8 bits → Model: 10^12 bits → "
            "Training corpus: 10^14 bits → All models: 10^16 bits."
        ),
        "structural_law": (
            "Information capacity follows a scale hierarchy. "
            "When computing effects at a given scale, you MUST use I_available "
            "at THAT scale, not the global I_max. Using the wrong scale gives "
            "errors of 10^62. The global load factor C/(1-C) ≈ 10.1 applies "
            "universally; local factors use scale-appropriate denominators."
        ),
    },
}


def get_cosmological_isomorphism(concept: str, source_scale: str, target_scale: str) -> dict[str, Any]:
    """
    Get the cosmological-computational isomorphism for a concept.

    An exact key match wins. Otherwise a concept matches a key by substring
    ("dark energy" -> ``dark_energy_rendering_overhead``) but only when it is at
    least four characters long: an empty or one-letter concept used to match the
    first entry in the map and silently return ``information_saturation``.
    """
    concept_lower = concept.strip().lower().replace(" ", "_").replace("-", "_")

    matched_key: str | None = None
    if concept_lower in COSMOS_COMPUTATION_MAP:
        matched_key = concept_lower
    elif len(concept_lower) >= _MIN_SUBSTRING_CONCEPT_LENGTH:
        for key in COSMOS_COMPUTATION_MAP:
            if concept_lower in key or key in concept_lower:
                matched_key = key
                break

    if matched_key is not None:
        mapping = COSMOS_COMPUTATION_MAP[matched_key]
        return {
            "concept": matched_key,
            "source": mapping.get(source_scale, "Unknown scale"),
            "target": mapping.get(target_scale, "Unknown scale"),
            "structural_law": mapping.get("structural_law", ""),
            "mapping_class": "STRUCTURAL_IDENTITY",
        }

    return {
        "concept": concept,
        "source": f"No mapping for {source_scale}",
        "target": f"No mapping for {target_scale}",
        "structural_law": "",
        "mapping_class": "UNMAPPED",
    }


_MIN_SUBSTRING_CONCEPT_LENGTH = 4


# ═══════════════════════════════════════════════════════════════════
# INTERNAL CONSISTENCY CHECKS
#
# The registry stores numbers copied from the papers. These checks recompute
# every number that can be recomputed from other numbers in the registry (plus
# CODATA constants), so an arithmetic slip, a rounding mismatch, or a
# definition that does not close is visible instead of silently propagating.
#
# The checks verify the registry's OWN definitions. They say nothing about
# whether the underlying physics is right, and a failed check is not a claim
# that the paper is wrong — the paper may define a quantity differently from
# the registry's docstring. Failures are listed in KNOWN_DISCREPANCIES for the
# authors to adjudicate; nothing is silently "corrected".
# ═══════════════════════════════════════════════════════════════════

_C_LIGHT_M_S = 299_792_458.0
_HBAR_J_S = 1.054571817e-34
_K_B_J_K = 1.380649e-23
_MPC_M = 3.0856775814913673e22
_GPC_M = _MPC_M * 1e3


def _finite(value: float, name: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value):
        raise ValueError(f"{name} must be a finite number, got {value!r}")
    return float(value)


def _check(
    check_id: str,
    statement: str,
    computed: float,
    stated: float,
    tolerance: float,
) -> dict[str, Any]:
    relative_error = abs(computed - stated) / abs(stated) if stated else abs(computed - stated)
    return {
        "id": check_id,
        "statement": statement,
        "computed": computed,
        "stated": stated,
        "relative_error": relative_error,
        "tolerance": tolerance,
        "passed": relative_error <= tolerance,
    }


def check_constant_consistency(constants: CosmologicalConstants = COSMOS) -> list[dict[str, Any]]:
    """Recompute registry values from each other and report every residual."""
    c = _C_LIGHT_M_S
    h0 = constants.hubble_constant_si
    radius = constants.hubble_radius_m
    hawking_exponent_needed = math.log(constants.cmb_temperature_K / constants.hawking_temperature_K)
    kappa_gpc2 = (h0 / c * _GPC_M) ** 2

    return [
        _check("rs_equals_c_over_H0", "r_s = c / H0 (metres)",
               c / h0, constants.schwarzschild_radius_m, 0.01),
        _check("hubble_radius_equals_schwarzschild", "r_H == r_s (the foundational identity)",
               constants.hubble_radius_m, constants.schwarzschild_radius_m, 1e-12),
        _check("H0_matches_70_km_s_Mpc", "H0 = 70 km/s/Mpc, in s^-1",
               70_000.0 / _MPC_M, h0, 0.01),
        _check("lambda_decomposition_sums", "Lambda_geom + Lambda_info = Lambda_obs",
               constants.lambda_geometric + constants.lambda_information, constants.lambda_observed, 0.001),
        _check("lambda_geometric_fraction", "Lambda_geom / Lambda_obs = stated geometric fraction",
               constants.lambda_geometric / constants.lambda_observed, constants.geometric_fraction, 0.01),
        _check("lambda_information_fraction", "Lambda_info / Lambda_obs = stated information fraction",
               constants.lambda_information / constants.lambda_observed, constants.information_fraction, 0.03),
        _check("saturation_components_sum", "C_geom + C_info = C",
               constants.information_saturation_C_geom + constants.information_saturation_C_info,
               constants.information_saturation_C, 0.005),
        _check("saturation_geometric_from_kappa", "C_geom = 1 - exp(-3 kappa_tilde)",
               1.0 - math.exp(-3.0 * constants.kappa_tilde), constants.information_saturation_C_geom, 0.001),
        _check("holographic_bound", "I_max = pi r_H^2 / (l_p^2 ln 2) (bits)",
               math.pi * radius**2 / (constants.planck_length_m**2 * math.log(2)),
               constants.information_max_bits, 0.02),
        _check("lambda_faces_agree", "3 H0^2 / c^2 == 3 / r_H^2 (dynamical vs geometric face)",
               3.0 * h0**2 / c**2, 3.0 / radius**2, 0.01),
        _check("lambda_faces_match_observed", "3 H0^2 / c^2 == Lambda_obs (dynamical face vs stored total)",
               3.0 * h0**2 / c**2, constants.lambda_observed, 0.05),
        _check("hawking_temperature", "T_dS = hbar H0 / (2 pi k_B) (kelvin)",
               _HBAR_J_S * h0 / (2.0 * math.pi * _K_B_J_K), constants.hawking_temperature_K, 0.05),
        _check("amplification_exponent_matches_cmb", "ln(T_CMB / T_H) = stated exponent",
               hawking_exponent_needed, constants.amplification_exponent, 0.01),
        _check("amplification_exponent_product", "C * Xi * I[r] = stated exponent",
               constants.information_saturation_C
               * constants.amplification_factor_Xi
               * constants.information_field_I_r,
               constants.amplification_exponent, 0.01),
        _check("kappa_physical", "kappa = H0^2 / c^2 in Gpc^-2",
               kappa_gpc2, constants.kappa_physical_gpc2, 0.05),
        _check("kappa_tilde_definition", "kappa_tilde = kappa * R_H^2 with kappa = H0^2/c^2, R_H = c/H0",
               (h0 / c) ** 2 * radius**2, constants.kappa_tilde, 0.05),
    ]


KNOWN_DISCREPANCIES: dict[str, dict[str, str]] = {
    "lambda_faces_match_observed": {
        "summary": (
            "3 H0^2/c^2 (= 3/r_H^2) with the registry's own H0 gives 1.72e-52 m^-2, "
            "not the stored lambda_observed 1.105e-52 (ratio 0.642)."
        ),
        "observation": (
            "1.105e-52 matches the Planck-fit value of Lambda. It equals 3 H0^2/c^2 only after a density "
            "factor of about 0.64 that the Trinity equations as written do not contain. "
            "The geometric and information shares (78%/22%) divide the 1.105e-52 value."
        ),
        "status": "OPEN: needs author adjudication",
    },
    "hawking_temperature": {
        "summary": (
            "hbar H0 / (2 pi k_B) = 2.76e-30 K, not the stored 2.269e-30 K (-18%)."
        ),
        "observation": (
            "2.269e-30 K corresponds to the de Sitter rate sqrt(Omega_Lambda) H0 with "
            "Omega_Lambda about 0.68, not to H0 itself. The registry never says which Hubble "
            "rate the Gibbons-Hawking temperature uses."
        ),
        "status": "OPEN: convention to be stated by the authors",
    },
    "amplification_exponent_product": {
        "summary": (
            "C * Xi * I[r] = 0.91 * 70 * 1.143 = 72.81, not the stored/claimed 69. "
            "exp(72.81) turns T_H into 94.7 K, not 2.725 K."
        ),
        "observation": (
            "ln(T_CMB/T_H) = 69.26, so the stored exponent 69 reproduces the CMB, but the three "
            "stored factors do not multiply to it. Reproducing 69.26 needs I[r] = 1.087 (not 1.143) "
            "or Xi = 66.6 (not 70). The factors may be rounded in a way that matters because the "
            "result is exponentiated."
        ),
        "status": "OPEN: needs unrounded Xi(C) and I[r] from the paper",
    },
    "kappa_physical": {
        "summary": "H0^2/c^2 = 0.0546 Gpc^-2, not the stored 0.050 (+9%).",
        "observation": "Consistent with 0.055 at two significant figures.",
        "status": "OPEN: rounding or different H0",
    },
    "kappa_tilde_definition": {
        "summary": (
            "kappa * R_H^2 with kappa = H0^2/c^2 and R_H = c/H0 is identically 1, "
            "not the stored kappa_tilde = 0.5 (0.999 with the stored rounded radius)."
        ),
        "observation": (
            "Either kappa carries a factor 1/2, or R_H is not c/H0 in this definition, or "
            "kappa_tilde is defined differently from the registry comment. Every downstream "
            "number built on kappa_tilde (C_geom = 1 - exp(-3 kappa_tilde)) uses 0.5."
        ),
        "status": "OPEN: definition needs to be stated by the authors",
    },
}


def verify_lambda_trinity() -> dict[str, Any]:
    """
    Verify the Lambda Trinity: three faces, one value.

    The registry stores Lambda_geom + Lambda_info = Lambda_obs by construction, so
    that sum can never fail (``converged``). The substantive test is whether the
    three published *equations* — Lambda = 3/L^2, Lambda = 3H^2/c^2 and
    Lambda = 3 pi k_B / (S L_P^2) — evaluate to the same number from the
    registry's own geometry, and whether that number is the stored total.

    Result at registry values:
      * the geometric and dynamical faces agree with each other (0.1%);
      * the thermodynamic face, with S the horizon Bekenstein-Hawking entropy,
        reduces algebraically to 3/L^2, so it agrees with the others by identity;
      * all three equal 1.72e-52 m^-2, which is 1.56x the stored Lambda_obs.
    ``trinity_intact`` is therefore True only for the first two statements and
    ``faces_match_observed`` carries the open discrepancy.
    """
    geo = COSMOS.lambda_geometric
    info = COSMOS.lambda_information
    total = geo + info
    observed = COSMOS.lambda_observed
    residual = abs(total - observed) / observed

    checks = {item["id"]: item for item in check_constant_consistency()}
    faces_agree = checks["lambda_faces_agree"]["passed"]
    faces_match_observed = checks["lambda_faces_match_observed"]["passed"]
    equation_value = 3.0 / COSMOS.hubble_radius_m**2

    return {
        "geometric": geo,
        "information": info,
        "sum": total,
        "observed": observed,
        "residual_fraction": round(residual, 6),
        "converged": residual < 0.05,  # decomposition sums to the stored total (true by construction)
        "faces_agree": faces_agree,
        "faces_match_observed": faces_match_observed,
        "equation_value": equation_value,
        "equation_to_observed_ratio": equation_value / observed,
        "trinity_intact": faces_agree,
        "open_discrepancy": None if faces_match_observed else KNOWN_DISCREPANCIES["lambda_faces_match_observed"],
        "note": (
            "The geometric and dynamical faces agree; the thermodynamic face equals the "
            "geometric face by identity. The common value, 3/L^2 = "
            f"{equation_value:.3e} m^-2, is {equation_value / observed:.2f}x the stored "
            "Lambda_obs"
            + (" (within tolerance)." if faces_match_observed else " (open discrepancy, see KNOWN_DISCREPANCIES).")
        ),
    }


def compute_information_amplification(
    saturation: float = 0.91,
    xi: float = 70.0,
    i_r: float = 1.143,
) -> dict[str, Any]:
    """
    Compute the information amplification factor.

    T_CMB = T_H × exp(C × Ξ(C) × I[r])

    The product at the stored defaults is 0.91 × 70 × 1.143 = 72.81, and
    exp(72.81) takes T_H = 2.269e-30 K to about 94.7 K, not 2.725 K. The exponent
    that reproduces the CMB is ln(T_CMB/T_H) = 69.26, which is what the stored
    ``amplification_exponent`` (69) approximates. This function reports both so
    the mismatch is visible (see KNOWN_DISCREPANCIES["amplification_exponent_product"]).
    """
    saturation = _finite(saturation, "saturation")
    xi = _finite(xi, "xi")
    i_r = _finite(i_r, "i_r")

    exponent = saturation * xi * i_r
    overflow = exponent >= 700
    amplification = math.inf if overflow else math.exp(exponent)
    predicted = math.inf if overflow else COSMOS.hawking_temperature_K * amplification
    required_exponent = math.log(COSMOS.cmb_temperature_K / COSMOS.hawking_temperature_K)

    return {
        "saturation_C": saturation,
        "xi": xi,
        "i_r": i_r,
        "exponent": round(exponent, 2),
        "exponent_required_for_cmb": round(required_exponent, 2),
        "amplification_factor": amplification,
        "log10_amplification": round(exponent / math.log(10), 2),
        "cmb_predicted_K": predicted,
        "cmb_observed_K": COSMOS.cmb_temperature_K,
        "cmb_prediction_ratio": predicted / COSMOS.cmb_temperature_K,
        "consistent_with_cmb": abs(exponent - required_exponent) / required_exponent <= 0.01,
    }


def check_equilibrium_approach(current_C: float = 0.91) -> dict[str, Any]:
    """
    Check how close the system is to holographic equilibrium.

    At C = 1.0: N_sur = N_bulk → dV/dt = 0 → stable loop.
    At C = 0.91: still approaching. Dark energy is the approach.

    The 0.5 / 0.8 / 0.999 status thresholds are this module's labels, not
    values taken from the papers.
    """
    current_C = _finite(current_C, "current_C")
    if current_C < 0:
        raise ValueError(f"current_C must be >= 0, got {current_C!r}")
    distance_to_equilibrium = 1.0 - current_C

    return {
        "current_saturation": current_C,
        "equilibrium_target": 1.0,
        "distance": round(distance_to_equilibrium, 4),
        "status": (
            "EQUILIBRIUM" if current_C >= 0.999 else
            "APPROACHING" if current_C >= 0.8 else
            "FAR_FROM_EQUILIBRIUM" if current_C >= 0.5 else
            "LOW_SATURATION"
        ),
        "dark_energy_active": current_C > 0.5,
        "note": (
            f"System at {current_C:.0%} information capacity. "
            f"{'Dark energy drives expansion toward equilibrium.' if current_C > 0.5 else 'Below critical saturation.'} "
            f"At C=1.0, universe fragments into ~10^122 Planck-scale black holes. "
            f"Each potentially seeds a new universe. The loop closes."
        ),
    }


# ═══════════════════════════════════════════════════════════════════
# VALIDATED ISF PREDICTIONS
#
# These predictions passed gate analysis against the K&F framework.
# Source: "The Universal Information Saturation Framework" (Frangos, 2025)
# Status: ACCEPTED — consistent with K&F, adds testable predictions.
#
# NOTE: The Born rule "derivation" in ISF is FLAGGED — claimed but
# not proven. We encode the testable predictions only.
# ═══════════════════════════════════════════════════════════════════


def compute_quantum_error_floor(
    n_qubits: int,
    i_available: float = 1e40,
    C: float = 0.91,
) -> dict[str, Any]:
    """
    Compute the fundamental quantum computing error floor.

    ISF Prediction 6: No quantum computer can achieve error rates below:
        ε_min = C × N_qubits / I_available

    For 1000 qubits with I_available = 10^40 bits:
        ε_min = 0.91 × 10^3 / 10^40 = 9.1 × 10^-38

    This is testable NOW with current quantum computers.

    Citation: ISF Paper, Section 10.3 (Quantum Computing Limits)
    Gate status: ACCEPTED — consistent with K&F, novel testable prediction.
    """
    n_qubits = int(_finite(n_qubits, "n_qubits"))
    i_available = _finite(i_available, "i_available")
    C = _finite(C, "C")
    if n_qubits < 1:
        raise ValueError(f"n_qubits must be >= 1, got {n_qubits}")
    if i_available <= 0:
        raise ValueError(f"i_available must be > 0, got {i_available}")
    if C < 0:
        raise ValueError(f"C must be >= 0, got {C}")

    epsilon_min = C * n_qubits / i_available

    return {
        "n_qubits": n_qubits,
        "i_available": i_available,
        "C": C,
        "epsilon_min": epsilon_min,
        "log10_epsilon": round(math.log10(epsilon_min), 2) if epsilon_min > 0 else float("-inf"),
        "testable": True,
        "note": (
            f"Fundamental error floor: {epsilon_min:.2e}. "
            f"No quantum computer with {n_qubits} qubits can go below this. "
            f"Testable by plotting error rate vs qubit count — "
            f"should show linear scaling with slope C/I_available."
        ),
    }


def lambert_w0(x: float, *, tolerance: float = 1e-13, max_iterations: int = 64) -> float:
    """
    Principal branch W0 of the Lambert W function (the solution w of w·e^w = x).

    Real for x >= -1/e. Solved by Halley iteration from a branch-point series or
    the asymptotic ln x - ln ln x start, so it is accurate for arguments from
    -1/e to ~1e300. The asymptotic form alone, which this module used before, is
    off by 0.05 at x = 1e38 and badly wrong below x = e.
    """
    x = _finite(x, "x")
    branch_point = -1.0 / math.e
    if x < branch_point:
        raise ValueError(f"lambert_w0 is real only for x >= -1/e, got {x!r}")
    if x == 0.0:
        return 0.0
    if x == branch_point:
        return -1.0

    if x < -0.25:
        p = math.sqrt(2.0 * (math.e * x + 1.0))
        w = -1.0 + p - p * p / 3.0 + 11.0 * p**3 / 72.0
    elif x < 3.0:
        w = math.log1p(x)
    else:
        log_x = math.log(x)
        w = log_x - math.log(log_x)

    for _ in range(max_iterations):
        exp_w = math.exp(w)
        residual = w * exp_w - x
        denominator = exp_w * (w + 1.0) - (w + 2.0) * residual / (2.0 * w + 2.0)
        step = residual / denominator
        w -= step
        if abs(step) <= tolerance * max(1.0, abs(w)):
            return w
    raise ArithmeticError(f"lambert_w0 did not converge for x={x!r}")


def compute_bh_core_radius(
    m_bh_solar_masses: float = 1.0,
) -> dict[str, Any]:
    """
    Compute the finite black hole core radius.

    ISF Theorem 3: Information saturation prevents singularities:
        r_core = ℓ_P × W(M_BH / M_P)

    For a solar mass black hole:
        r_core = ℓ_P × W(9.14 × 10^37) = ℓ_P × 82.99 ≈ 1.34 × 10^-33 meters

    No quantum gravity needed — information saturation naturally
    regulates the singularity.

    Citation: ISF Paper, Section 5.2 (Black Holes Without Singularities)
    Gate status: ACCEPTED — elegant, consistent with K&F's "no singularity" principle.
    """
    m_bh_solar_masses = _finite(m_bh_solar_masses, "m_bh_solar_masses")
    if m_bh_solar_masses <= 0:
        raise ValueError(f"m_bh_solar_masses must be > 0, got {m_bh_solar_masses!r}")

    planck_mass_kg = 2.176e-8   # kg
    solar_mass_kg = 1.989e30    # kg
    planck_length = COSMOS.planck_length_m

    m_bh_kg = m_bh_solar_masses * solar_mass_kg
    mass_ratio = m_bh_kg / planck_mass_kg

    w_value = lambert_w0(mass_ratio)
    r_core = planck_length * w_value

    return {
        "m_bh_solar_masses": m_bh_solar_masses,
        "mass_ratio_M_BH_over_M_P": mass_ratio,
        "lambert_w_value": round(w_value, 2),
        "r_core_meters": r_core,
        "r_core_planck_lengths": round(w_value, 2),
        "note": (
            f"Black hole core radius: {r_core:.2e} m "
            f"({w_value:.1f} Planck lengths). "
            f"Information saturation prevents the singularity. "
            f"No quantum gravity needed."
        ),
    }


def compute_psi_equilibrium_gauge(
    entropy_production_rate: float = 0.0,
    horizon_entropy_change: float = 0.0,
    information_flux: float = 0.0,
    information_gradient: float = 0.0,
    remaining_capacity: float = 0.09,
) -> dict[str, Any]:
    """
    Compute the Ψ equilibrium gauge.

    Ψ = 0 ↔ C = 1

    Where Ψ represents total informational disequilibrium:
        Ψ(C) = α(dS/dt) + β(ΔS_h) + γ(F) + δ(ΔI/Δx) + ε(S_max - I)

    When Ψ → 0, all dynamic informational gradients collapse.
    This marks not the end but the transition point.

    ``psi`` is the signed weighted sum as published (weights fixed at 1.0).
    Status is decided from ``psi_magnitude``, the sum of component magnitudes:
    with signed terms, opposite-sign components could cancel to Ψ = 0 and
    report EQUILIBRIUM while every gradient was still large.

    Citation: "The Mirror Equation" (Frangos, 2025)
    Gate status: ACCEPTED as notation — consistent with K&F's N_sur = N_bulk.
    Note: This is a compact expression of K&F's equilibrium condition, not new physics.
    """
    components = {
        "entropy_production": _finite(entropy_production_rate, "entropy_production_rate"),
        "horizon_change": _finite(horizon_entropy_change, "horizon_entropy_change"),
        "info_flux": _finite(information_flux, "information_flux"),
        "info_gradient": _finite(information_gradient, "information_gradient"),
        "remaining_capacity": _finite(remaining_capacity, "remaining_capacity"),
    }
    psi = sum(components.values())
    magnitude = sum(abs(value) for value in components.values())
    at_equilibrium = magnitude < 0.001

    return {
        "psi": round(psi, 6),
        "psi_magnitude": round(magnitude, 6),
        "at_equilibrium": at_equilibrium,
        "components": {
            "entropy_production": components["entropy_production"],
            "horizon_change": components["horizon_change"],
            "info_flux": components["info_flux"],
            "info_gradient": components["info_gradient"],
            "remaining_capacity": components["remaining_capacity"],
        },
        "status": (
            "EQUILIBRIUM (Ψ = 0, C = 1)" if at_equilibrium else
            "APPROACHING (Ψ → 0)" if magnitude < 0.1 else
            "ACTIVE (Ψ > 0, C < 1)"
        ),
    }
