"""V2.2 Medical-Ontology System Decompression."""
import re
from dataclasses import dataclass
from semantic_compiler.core.packet import SemanticPacket
from semantic_compiler.expansion.ontology.medical_ontology import MEDICAL_ONTOLOGY
from semantic_compiler.expansion.registry import get_template
from semantic_compiler.expansion.pathology import detect_pathologies
from semantic_compiler.expansion.isomorphism import build_functional_graph
from semantic_compiler.expansion.reconstruction import reconstruct_missing, assess_completeness
from semantic_compiler.expansion.advisor import generate_advice
from semantic_compiler.expansion.schema.v2_2_system_model import validate_system_model
from semantic_compiler.expansion.gem_decode import decode_build, GemDecodeResult
from semantic_compiler.expansion.gem_forge import (
    ForgeResult,
    GemTranslation,
    PoeGem,
    SoftwareComponent,
    forge_component,
    load_gem_corpus,
    load_gem_corpus_file,
    translate_corpus,
    translate_gem,
)

@dataclass(frozen=True)
class SystemModel:
    domain: str
    decompression_version: str
    components: list[dict]
    relationships: list[dict]
    universal_functional_graph: dict
    pathology_profile: dict
    reconstruction: dict
    advisor: dict

def decompress(packet: SemanticPacket) -> dict:
    """Decompress a SemanticPacket into a V2.2 system model."""
    domain = _infer_domain(packet)
    template = get_template(domain)

    components = _extract_components(packet, template)
    relationships = _extract_relationships(packet)

    graph = build_functional_graph({"components": components, "relationships": relationships}, template)
    pathologies = detect_pathologies({"components": components, "relationships": relationships}, template)
    missing = reconstruct_missing({"components": components, "relationships": relationships}, template)
    completeness = assess_completeness({"components": components, "relationships": relationships}, template)
    advice = generate_advice({"components": components, "relationships": relationships}, pathologies, missing, failure_modes=template.failure_modes)

    model = {
        "domain": domain,
        "decompression_version": "2.2.0-rc1",
        "components": components,
        "relationships": relationships,
        "universal_functional_graph": {
            "nodes": list(graph.nodes),
            "edges": graph.edges,
            "coverage_ratio": graph.coverage_ratio,
        },
        "pathology_profile": {
            "detected_pathologies": [p.name for p in pathologies],
            "medical_diagnoses": [
                {
                    "pathology": p.name,
                    "medical_map": p.medical_map,
                    "evidence": p.evidence,
                    "confidence": p.confidence,
                } for p in pathologies
            ],
        },
        "reconstruction": {
            "missing_components": [
                {
                    "function": m.function,
                    "inferred_by": m.inferred_by,
                    "source_domain": m.source_domain,
                    "confidence": m.confidence,
                    "status": m.status,
                } for m in missing
            ],
            "completeness_scope": completeness,
        },
        "advisor": {
            "diagnosis": [s.description for s in advice["diagnosis"]],
            "prescriptions": [s.description for s in advice["prescriptions"]],
            "architecture_improvements": [s.description for s in advice["architecture_improvements"]],
            "resilience_training": [s.description for s in advice["resilience_training"]],
            "prognosis": advice["prognosis"],
        },
    }

    errors = validate_system_model(model)
    if errors:
        raise ValueError(f"Invalid system model: {errors}")
    return model

_DOMAIN_KEYWORDS: tuple[tuple[str, tuple[str, ...]], ...] = (
    # Order is the precedence: the first domain with a hit wins. The deep-system
    # domains come first because their vocabulary is specific (a text about an
    # Android bootloader or DNSSEC is also "about a network" in the loose sense
    # that the generic computation keywords catch). Then the original
    # computation > biology > medical > generic order, unchanged.
    ("mobile_security", (
        "android", "knox", "trustzone", "bootloader", "selinux", "keystore",
        "verified boot", "secure boot", "secure world", "warranty bit",
    )),
    ("networking", (
        "bgp", "dns", "dnssec", "rpki", "tcp", "udp", "autonomous system",
    )),
    ("trust_chain", (
        "chain of trust", "root of trust", "trust anchor", "remote attestation",
        "code signing", "certificate chain",
    )),
    # Narrow on purpose: bare "path of exile" is not a keyword because Buildcraft and
    # gem-decode use PoE shorthand to describe computation builds.
    ("poe_chaos_inoculation", (
        "chaos inoculation", "energy shield", "eldritch battery", "ghost reaver",
    )),
    ("computation", ("firewall", "network", "server", "api", "database")),
    ("biology", ("cell", "organism", "immune", "immunity", "immunology", "metabolism")),
    ("medical", (
        "patient", "hospital", "clinical", "clinician", "clinic", "surgery", "surgeon",
        "diagnosis", "diagnosed", "prognosis", "triage", "nurse", "physician", "doctor",
        "symptom", "sepsis",
    )),
)


def _keyword_pattern(keywords: tuple[str, ...]) -> re.Pattern[str]:
    # Whole words with an optional plural: "api" must not match "rapid", "server"
    # must not match "observer", "cell" must not match "excellent".
    return re.compile(r"(?<![a-z])(?:" + "|".join(map(re.escape, keywords)) + r")(?:s|es)?(?![a-z])")


_DOMAIN_PATTERNS = tuple((domain, _keyword_pattern(words)) for domain, words in _DOMAIN_KEYWORDS)


def _infer_domain(packet: SemanticPacket) -> str:
    """Simple domain inference from packet text (whole-word keyword match)."""
    text = (packet.raw_input or "").lower()
    for domain, pattern in _DOMAIN_PATTERNS:
        if pattern.search(text):
            return domain
    return "universal_generic"

def _extract_components(packet: SemanticPacket, template) -> list[dict]:
    """Extract components from packet skeleton."""
    components = []
    for comp in template.components:
        # A template may state a component's medical-ontology concept itself; it is
        # used only when it is a canonical concept, otherwise fall back to the
        # name-based inference (all templates written before the field existed).
        declared = comp.get("medical_map")
        medical_map = declared if declared in MEDICAL_ONTOLOGY else _infer_medical_map(comp["name"])
        components.append({
            "name": comp["name"],
            "function": comp["function"],
            "medical_map": medical_map,
            "status": "inferred_by_analogy",
            "confidence": 0.6,
        })
    return components

def _extract_relationships(packet: SemanticPacket) -> list[dict]:
    """Extract relationships from packet."""
    return []

def _infer_medical_map(component_name: str) -> str:
    """Infer medical ontology mapping for a component."""
    mapping = {
        "input_layer": "immune_boundary",
        "processing_core": "processing_core",
        "memory_store": "memory_store",
        "defense_boundary": "immune_system",
        "output_layer": "output_layer",
        "cell_membrane": "immune_boundary",
        "metabolism": "homeostasis_regulation",
        "immune_system": "immune_system",
        "genetic_code": "memory_store",
        "homeostasis_regulation": "homeostasis_regulation",
    }
    if component_name in mapping:
        return mapping[component_name]
    # Components named after an ontology concept (the medical template's
    # "diagnosis" and "treatment") map to that concept instead of "unknown".
    if component_name in MEDICAL_ONTOLOGY:
        return component_name
    return "unknown"


__all__ = [
    "SystemModel",
    "decompress",
    "decode_build",
    "GemDecodeResult",
    "PoeGem",
    "SoftwareComponent",
    "GemTranslation",
    "ForgeResult",
    "load_gem_corpus",
    "load_gem_corpus_file",
    "translate_gem",
    "translate_corpus",
    "forge_component",
]
