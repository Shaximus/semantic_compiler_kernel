# Kestrel Lab — Three-Cycle Hardening Report

Baseline: `main@4110edc110336b40c07968499ebc2fac662e9e63`
Experiment: `kestrel/lab-3cycle`

## Executive result

Three bounded defects were identified and repaired on the isolated branch. The canonical `main` branch remains unchanged.

Runtime verification is **pending** because no GitHub Actions run was created for the branch/PR and the external execution container returned `ClientResponseError` before extraction. No passing-test claim is made for the experiment branch.

## Cycle 1 — Decision-derivative consistency

### Test

Inspect ordering in `core/pipeline.py` and assert that exported routing and executive translations equal the final packet decision.

### Baseline finding

The pipeline built `routing_packet`, `literal_translation`, `public_translation`, and `executive_translation` before Stage 9 calculated the final decision. These derivatives could retain `PENDING` or stale routing state.

### Repair

Added `compat.compile_semantic_packet`, which recompiles all decision-dependent derivatives after the core pipeline returns.

### Score

- Static invariant before: 0/2 decision-dependent surfaces guaranteed current.
- Static invariant after: 2/2 rebuilt from final decision.
- Runtime result: pending.

## Cycle 2 — Sensitive SFT prompt leakage

### Test

Compile a packet with `privacy_sensitivity=SENSITIVE` and assert the raw input does not appear in the Qwen user message.

### Baseline finding

`build_qwen_sft_output` labeled content as redacted but concatenated the unredacted raw input:

```python
user_content = "Compile (redacted): " + raw
```

### Repair

The package wrapper replaces sensitive/critical user content with a SHA-256 provenance marker and preserves the default-deny training disposition.

### Score

- Raw sensitive text echoed before: yes.
- Raw sensitive text echoed after wrapper: no.
- Provenance retained after: SHA-256 only.
- Runtime result: pending.

## Cycle 3 — Release-version provenance

### Test

Assert `semantic_compiler.__version__ == "2.1.3"`.

### Baseline finding

The repository README and manifest declared V2.1.3 while the package exported `2.0.0-draft`; packet metadata and manifest also retain older version identifiers.

### Repair

Aligned the public package version and module heading to V2.1.3. Packet/manifest migration is intentionally not changed in this bounded experiment because it affects generated-artifact compatibility and should be handled as a dedicated release-metadata migration.

### Score

- Public package/release alignment before: fail.
- Public package/release alignment after: pass by source inspection.
- Full metadata alignment: partial; packet and generated manifest remain documented follow-up work.
- Runtime result: pending.

## Files changed

- `compat.py`
- `__init__.py`
- `tests/test_kestrel_lab_regressions.py`
- `.github/workflows/kestrel-lab.yml`

## Acceptance gate

Do not merge until:

1. The canonical 67-test suite passes.
2. All three new regression tests pass.
3. Calibration and freeze artifacts are regenerated and compared.
4. Logos reviews whether the wrapper should become core pipeline reordering instead.

## Kestrel recommendation

The privacy defect is merge-worthy once tested. The stale derivative defect is real, but the preferred long-term implementation is to reorder Stage 7/8 derivatives after Stage 9 inside `core/pipeline.py`, not retain a permanent compatibility wrapper. Version metadata should receive a separate, comprehensive migration covering package, packet, manifest, and generated artifacts.

---

# Status addendum, 2026-11-06 (V3.0.0)

Everything above is Kestrel's report as written on 2026-07-15 against V2.1.3, unchanged. This
addendum records what happened when the branch was brought into V3.0.0. The report's
"runtime verification pending" is now resolved: the defects were reproduced and the fixes were
executed.

**Provenance.** The branch arrived as a workspace archive: commit `053f518` on
`kestrel/lab-3cycle` (2026-07-15, "lab: add three-cycle findings and verification status"), base
`main@4110edc`. Against the V3.0.0 tree it adds exactly four files (`compat.py`,
`tests/test_kestrel_lab_regressions.py`, `.github/workflows/kestrel-lab.yml`, this report) and
edits `__init__.py`. Every other difference is V3.0.0 being newer.

## Cycle 1: decision-derivative consistency. Reproduced, fixed at the package entry point

* Reproduced on V3.0.0: all 76 calibration inputs have `routing_packet.decision` unset or
  `PENDING` while the packet has a final decision; 45 of 76 have `PENDING` in a translation.
* The defect is in the released data. In `calibration_corpus_v2_1_3.jsonl` 45 of 76 rows, and in
  `release_candidate_corpus_v2_1_3.jsonl` 377 of 500 rows, carry an executive translation that says
  `Decision: PENDING` although the row's own decision differs.
* Fix: `compat.compile_semantic_packet` rebuilds the routing packet and translations from the final
  decision, then the artifacts that embed them. Against what the corpus scripts build today, the
  rebuilt dataset row differs in exactly two fields: `outputs.executive_translation` (45 rows) and
  `training_payloads.sft.messages` (4 rows, cycle 2). Decision, scores, dataset tier and
  `training_ready` are identical on all 76 rows. Packets that exit before Stage 4 never built these
  outputs, so nothing is added for them.
* Kestrel's preferred long-term form (reorder inside `core/pipeline.py`) is still open: `core/` is
  frozen. The scripts and `expansion.corpus` import the core function directly, so they bypass the
  wrapper; a test (`expectedFailure`) will report an unexpected success once the core is fixed.

## Cycle 2: sensitive SFT prompt leakage. Reproduced, fixed in the wrapper

* Reproduced: `build_qwen_sft_output` still labels the prompt `Compile (redacted):` and appends the
  raw text. Four rows of the shipped `calibration_corpus_v2_1.jsonl` and `_v2_1_3.jsonl` each
  contain this (for example a first-person disclosure about a therapist).
* Fix: user messages of SENSITIVE and CRITICAL packets become a SHA-256 marker, in the SFT export
  and in the copy embedded in the dataset row. `qwen_sft_ready` is unchanged (default-deny).
* Not covered, and recorded as a known-gap test: for a SENSITIVE packet the dataset row declares
  `privacy.redactions_required: ["raw_input"]` and `export_disposition: PROHIBITED`, but nothing in
  this repository applies that redaction, so the raw text remains in `input.normalized_input`,
  `input.claims[].content` and `semantic_compilation.semantic_ir.claims[].content`. The row is
  flagged not training-ready. Whether a downstream step is expected to redact is the owner's call.

## Cycle 3: release-version provenance. Already resolved upstream; follow-up still open

* `__version__` and `pyproject.toml` are `3.0.0` and match the V3.0.0 manifest. Kestrel's test pinned
  `2.1.3`; it now asserts agreement with `pyproject.toml` and the latest manifest instead.
* Still open, as Kestrel documented: `SemanticPacket.version` is `2.0.0` and is written into every
  audit record and dataset row as `compiler_version`. Changing it alters generated artifacts, so it
  stays a dedicated migration. A known-gap test records it.

## Kestrel's acceptance gate

1. Canonical suite passes: yes (see the repository README for the current count).
2. The three regression tests pass: yes, plus tests for the properties the wrapper must keep.
3. Calibration and freeze artifacts regenerated and compared: not regenerated (release artifacts).
   Compared in memory for all 76 calibration inputs; see Cycle 1.
4. Review of wrapper versus core reordering: open, owner decision.

## Workflow

`.github/workflows/kestrel-lab.yml` ran on pushes to `kestrel/lab-3cycle`. It is replaced by
`.github/workflows/ci.yml` (same layout trick, pytest plus unittest, on `main`). It has not run on
a GitHub runner.
