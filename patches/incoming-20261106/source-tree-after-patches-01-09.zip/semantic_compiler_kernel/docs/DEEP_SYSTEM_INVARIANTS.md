# Deep-system invariants: mobile security, networking, chain of trust

Added 2026-11-06 as three domain templates in `expansion/templates/`:

| Domain | File | What it models |
|---|---|---|
| `mobile_security` | `mobile_security.yaml` | Android platform + Samsung Knox: boot chain, rollback, sandboxing, secure world, key custody, runtime kernel integrity, attestation |
| `networking` | `networking.yaml` | The four invariants of networked systems, the RFC 1958 principles, RPKI routing authorization, DNSSEC naming |
| `trust_chain` | `trust_chain.yaml` | The pattern the other two share (and that DNSSEC and the RPKI share with them): anchor, verified delegation, freshness, enforced failure policy, compromise record, stated scope |

## How to read the provenance

* Every **invariant** in these templates ends with one or more source tags, e.g. `[KNOX-WP]`.
  The tags are defined in the table below, and `tests/expansion/test_deep_system_templates.py`
  fails if an invariant has no tag or uses an undefined one.
* **Failure modes and architecture patterns are the template author's mappings**
  onto the medical ontology. They are derived from the invariants (what breaks if the
  invariant is violated), not quoted from the sources.
* Provenance is **page level**. A tag says the claim is stated by that document, not
  which paragraph.
* This is **research-derived and has not been reviewed by a domain expert** (platform
  security engineer, network operator). Treat it as a sourced first draft.

## Sources

| Tag | Source | URL |
|---|---|---|
| `AOSP-VB` | Android Open Source Project, Verified Boot | https://source.android.com/docs/security/features/verifiedboot |
| `AOSP-SEC` | Android Open Source Project, security features overview and system and kernel security | https://source.android.com/docs/security/features , https://source.android.com/docs/security/overview/kernel-security |
| `KNOX-WP` | Samsung Knox security white paper (r1) | https://docs.samsungknox.com/admin/fundamentals/whitepaper/samsung-knox-mobile-security/assets/Knox-security-white-paper-r1.pdf |
| `KW-2016` | Kanonov and Wool, "Secure Containers in Android: the Samsung KNOX Case Study", arXiv:1605.08567 | https://www.arxiv.org/abs/1605.08567 |
| `UCSB-176C` | UCSB CS176C, week 1 lecture 2, "The four invariants" | https://sites.cs.ucsb.edu/~arpitgupta/cs176c/spring26/assets/slides/week01_lecture02_four_invariants.html |
| `RFC1958` | RFC 1958, Architectural Principles of the Internet | https://www.rfc-editor.org/rfc/rfc1958 |
| `RFC4033` | RFC 4033, DNS Security Introduction and Requirements | https://datatracker.ietf.org/doc/html/rfc4033 |
| `RFC6480` | RFC 6480, An Infrastructure to Support Secure Internet Routing | https://datatracker.ietf.org/doc/html/rfc6480 |

## The shared pattern (why `trust_chain` exists)

The same structure appears in four independently designed systems. The cells below
are what the cited document states; `-` means it was not stated in what was read, not
that the property is absent.

| Property | Android (Verified Boot + platform) | Samsung Knox | DNSSEC | RPKI |
|---|---|---|---|---|
| Anchor outside the subject's control | hardware-protected root of trust | boot ROM; public half of the secure-boot key in one-time-programmable fuses | configured trust anchor | hierarchy rooted at IANA |
| Each link verified by the previous one | each stage verifies the next before handoff | each boot component authenticated before the next runs | DNSKEY to [DS to DNSKEY]* to RRset | issuer certificate to subordinate certificate |
| Freshness | rollback protection (Android 8.0+ with AVB) | rollback fuses; trusted boot rejects out-of-date loaders; nonce-bound attestation | expired or missing signatures yield Bogus | manifests expose stale replacement |
| Enforced failure consequence | strict enforcement since 7.0 blocks boot | boot terminates when a signature step fails; a bootable unapproved configuration permanently sets the warranty bit | Bogus is a distinct outcome | - |
| Narrow authority | - | - | a DS record vouches for a child's keys | an end-entity key signs exactly one object; a ROA names one AS |
| Compromise recorded monotonically | - | warranty bit (permanent eFuse) gates device-bound keys | - | - |
| Channel untrusted | - | - | - | repository untrusted; signatures plus manifests |
| Replacement without a gap | - | - | - | revoke only after a valid replacement exists |
| Stated limits | a kernel bug yielding root can bypass platform protections | KW-2016 documents weaknesses (monitor key generated in the normal world, shared certificate store and clipboard between containers) | no confidentiality, no protection against denial of service | authorization, not identity |

## What was not read or not established

* **"Eris" could not be identified.** Several searches combining it with Android, Knox,
  TrustZone and networking found nothing, and KW-2016 explicitly does not mention it.
  No template content is attributed to it. If it names a specific system, send its
  documentation and the template can be extended.
* The Knox white paper was read for roughly its first 100,000 of about 159,658
  characters. Knox Guard and anything in the remainder is not covered.
* RPKI coverage is the architecture RFC (6480) only: no BGP origin validation
  procedures, no RTR protocol, no operational deployment data.
* DNSSEC coverage is the introduction RFC (4033) only: no NSEC3, key-rollover or
  algorithm-agility details.
* The four invariants (interface, coordination, state, time) are taken from one
  university lecture. They are named but not elaborated into sub-invariants.
* RFC 1958 is a 1996 document. Its robustness principle ("be strict when sending and
  tolerant when receiving") is included because RFC 1958 states it; later IETF work has
  questioned it and that later work was not read here.

## Engine changes that ship with the templates

* `expansion/__init__.py`: `_DOMAIN_KEYWORDS` has three new groups ahead of
  `computation`, matching only specific vocabulary (for example `android`, `knox`,
  `bootloader`, `dns`, `dnssec`, `rpki`, `chain of trust`, `trust anchor`). A text that
  contains none of them routes exactly as before; the test suite pins that for every
  pre-existing calibration sample.
* Components may declare an optional `medical_map` (canonical concept names only).
  `decompress` uses it when valid and falls back to the old name-based inference
  otherwise, so the 19 older templates are unchanged.
* The new templates keep component concepts (`immune_system`, `quarantine`,
  `vaccination`, `homeostasis`, `diagnosis`, `physiotherapy`, `prognosis`) disjoint from
  failure-mode concepts (`pathogen`, `sepsis`, `metastasis`, `autoimmune`, `chronic`,
  `acute`, `inflammation`, `cancer`). `detect_pathologies` treats a component and
  failure mode that share a concept as direct evidence (confidence 0.75), so an overlap
  would raise a failure mode's confidence for reasons that have nothing to do with the
  input. A test enforces the separation.
