# Semantic Compiler Kernel

A semantic compilation and isomorphism-analysis pipeline that converts raw natural language into structured, schema-validated training data for language-model fine-tuning.

## Status

**Current release:** `V3.0.0` (canon freeze, 2026-07-23) — supersedes V2.3.0

- 378 tests passing plus 4 expected failures (documented known gaps) via
  `python -m pytest tests`; `python -m unittest discover` also runs clean
  (151 unittest-style tests, the same 4 expected failures; the remaining
  expansion tests are pytest-style function tests)
- `semantic_compiler.compile_semantic_packet` is the Kestrel Lab wrapper in
  `compat.py`: after the frozen core pipeline returns it rebuilds the routing
  packet, translations, SFT export, dataset row and audit record from the final
  decision, and redacts sensitive text from the SFT prompt. Callers that import
  `core.pipeline.compile_semantic_packet` directly (the corpus scripts,
  `expansion.corpus`) bypass it. See `docs/kestrel/Kestrel_Lab_3_Cycle_Report.md`.
- Core schema version: `2.1.0` (frozen; `core/`, `extraction/`, `gates/`, `registry/` untouched)
- Packaged with `pyproject.toml` (setuptools): `pip install -e .` from a fresh
  clone makes `semantic_compiler` importable everywhere — no `PYTHONPATH` hacks
- Corpus orchestration + cross-document invariant registry in `expansion.corpus`
- Buildcraft compute ontology available in `registry/` and `translation/`
  (BUILD_001–018, incl. MTP = Greater Multiple Projectiles with
  acceptance-rate = accuracy-rating invariant), resolved by a two-layer
  relation-aware structural + trigger-recall resolver
- **Gem → inference executable translation mode** in `expansion.gem_decode`,
  with deterministic build-archetype detection (IDENTIFIED vs ATTEMPTING)
- **Gem Forge** in `expansion.gem_forge` — all-gem inference translation over a
  pinned, hash-verified 1,017-gem RePoE corpus (CONVERTED 73.9% of 7,688
  lines), multi-gem composite synthesis with matcher floor (no degenerate
  single-primitive composites), NOVEL-effect protection, and primitive
  aliasing (`SHARE_STATE` → `PERSISTENT_SHARED_MODIFIER`)
- Registry gap updates from the 2026-07 corpus-mapping swarm
  (CORPUS_GAP_NEGATIVE_SAMPLES incl. NEG_011 fabricated_citation_anchor,
  2 new pathology failure modes)
- Rx /skill decompression mode in `expansion.skill_decompression`
- Manifest: `calibration_output/RELEASE_MANIFEST_V3_0_0.json`

V3.0.0 consolidates (founder directive 2026-07-23): mission-readiness
packaging, corpus orchestration, gem_decode, build-archetype detection,
registry gap updates, the structural resolver — and adds Gem Forge
(PRs #4–#8). Manifest chain: V2_1_3 → V2_3_0 → V3_0_0.

## What it does

1. **Extraction** — skeleton (actors/objects), relationships, claims, evidence, frames
2. **Semantic IR** — normalized intermediate representation
3. **Gates** — security, boundaries, causality, measurement, corpus completeness, contradiction repair, missing-organ scope
4. **Scoring** — mapping quality, assessment coverage, isomorphism quality
5. **Dataset export** — schema-validated JSONL for SFT/DPO/contrastive training

## V2.2 expansion — medical-ontology decompression

The `expansion/` layer adds system decompression on top of the frozen V2.1.3
core: given a `SemanticPacket`, `expansion.decompress()` reconstructs the
whole system the input describes, diagnoses its failure modes in
medical-ontology terms, and advises on treatment.

- **23 domain templates** (`expansion/templates/`, via `expansion.registry`) —
  biology, computation, construction, corporate, ecology, economic,
  environmental, evolutionary, finance_economics, government, informational,
  law, medical, military, mobile_security, networking, organizational,
  poe_chaos_inoculation, psychology, reflexion, social, trust_chain, plus the
  universal_generic fallback. `mobile_security` (Android and Samsung Knox), `networking`
  (RFC 1958 principles, RPKI, DNSSEC) and `trust_chain` (the pattern they
  share) carry source-tagged invariants; see
  [`docs/DEEP_SYSTEM_INVARIANTS.md`](docs/DEEP_SYSTEM_INVARIANTS.md) for the
  sources, the cross-source table and what was not established.
  `poe_chaos_inoculation` models the Path of Exile Chaos Inoculation keystone
  (maximum life 1, immune to chaos damage, energy shield as the only buffer).
  Its invariants name the game version they were sourced for and treat recharge
  numbers as patch-dependent. `tests/expansion/test_poe_ci_reference_model.py` is a
  toy state machine of the spec that checks the derived properties; see
  [`docs/POE_CHAOS_INOCULATION_INVARIANTS.md`](docs/POE_CHAOS_INOCULATION_INVARIANTS.md).
- **Pathology taxonomy** (`expansion.pathology`) — structural pathologies
  (boundary_breach, cancer, autoimmune, prompt_injection, data_corruption,
  ...) mapped to medical diagnoses with evidence and confidence
- **Isomorphism overlay** (`expansion.isomorphism`) — universal functional
  graph with coverage ratios
- **Reconstruction** (`expansion.reconstruction`) — missing-component
  inference by cross-domain analogy plus scope-aware completeness assessment
- **Architecture advisor** (`expansion.advisor`) — diagnosis, prescriptions,
  architecture improvements, resilience training, prognosis
- **V2.2 system-model schema** (`expansion/schemas/v2_2_system_model.schema.json`)
  — every decompressed model is validated before return

Calibration: `calibration_output/decompression_calibration_v2_2.jsonl`
(80 rows, 8 categories × 10, 16 domains × 5, 100% schema-valid) with the full
analysis in `calibration_output/DECOMPRESSION_CALIBRATION_REPORT_V2_2.md`.

## V2.2 expansion — corpus mapping and mission readiness

Additional expansion modules supporting multi-document corpus mapping into a
cross-document **invariant registry** (all deterministic, no LLM calls):

- **Corpus orchestration** (`expansion.corpus`) — `compile_corpus()` accepts
  document paths, `(doc_id, text, metadata)` tuples, or dicts; chunks long
  documents paragraph/section-aware with exact source offsets; compiles each
  chunk with document metadata in the context dict; aggregates a corpus-level
  report whose `invariant_registry` records recurring structural fingerprints
  with supporting documents+locations, confirmations, scoped disconfirmations,
  evidence tier, verdict, timestamps, and a derivation event log.
- **Evidence tiers** (`expansion.evidence_tiers`) — five mission-facing tiers
  (PRIMARY_RECORD, PUBLISHED_RESEARCH, SELF_ASSESSED_ESTIMATE,
  AI_GENERATED_ASSESSMENT, MARKED_SPECULATION) mapped from the frozen
  `EvidenceSourceType` / `EVIDENCE_PRIORITY` machinery.
- **Counter-mapping** (`expansion.counter_mapping`) — attach real
  disconfirmations (counterexamples, source/target-only features) to mappings
  so they flow through the frozen pipeline into dataset-row `negative_tests[]`;
  "searched but not found" is recorded with an auditable scope, never as
  confirmed absence.
- **Derivation order** (`expansion.derivation_order`) — per-claim/per-invariant
  event log tracking whether derivation preceded exposure to a parallel
  account (`True`/`False`/`None`, never guessed).
- **Verdict translation** (`expansion.verdicts`) — maps the frozen verdict
  machinery onto HOLDS / STRAINS / UNRESOLVED (documented mapping table).
- **Invariant-registry schema** (`expansion/schemas/v2_2_invariant_registry.schema.json`,
  Draft 2020-12) — validates the corpus report and registry entries; the
  domain-template and V2.2 system-model validators now use real `jsonschema`
  validation as well.
- **Advisor content** (`expansion.advisor`) — prescriptions and resilience
  training are now populated rule-based from the pathology taxonomy and
  template failure modes (vaccination-style indicator drills, graduated load
  drills for reconstructed components).

## Gem → inference executable translation (`expansion.gem_decode`)

Decompiles a build specification written in PoE skill/support-gem language
into an inference-architecture build sheet with executable checks. Gem
language is a fixed five-layer vocabulary with deterministic composition
rules — one of the cleanest possible executable translation domains:

```text
Equipment    → permanently installed hardware (case = character select, motherboard = race, GPU = weapon, CPU = body armour)
Active skill → the primary payload (LLM weights = active skill gem)
Support gem  → execution mechanics (CUDA/PyTorch/vLLM/MTP/cache/framework; MTP = GMP, acceptance rate = accuracy rating)
Aura         → persistent modifier fields (BCC, doctrine, system prompt, KV reuse, scheduler, TokenRouter, Auris, world state)
Anointment   → certified portable doctrine overlays (Calibrated Dissent etc.; oils = evidence tiers; no retraining)
Flask        → temporary bounded burst modes (Dying Sun = auxiliary compute fan-out; charges = concurrency budget; fail-open)
```

- **Parser** — both dialects: PoE-native gem chains (`"Ice Nova + Cast on
  Critical Strike + …; weapon: …; auras: …"`) and Reflexion-native keyed
  sections (`"verifier: …; draft: …; supports: …"`). Unknown section keys
  raise loudly instead of misclassifying silently.
- **Translator** — maps every component onto its computational analogue via
  the five-layer ontology, reusing BUILD_001–018 by reference (the frozen
  registry is not edited). Position-aware: the auxiliary i9 is equipment but
  plays the Dying Sun role in flask position. Output in two forms: a
  founder-readable markdown build sheet and schema-validated JSON
  (`expansion/schemas/v2_2_gem_build.schema.json`, Draft 2020-12).
- **Executable checks** — the COGNITIVE_COSPRI_001 cadence law
  (draft rate ≤ verifier acceptance capacity · prefetch lead ≥ decompression
  + transfer latency · concurrent sequences ≤ KV/VRAM budget · trigger
  frequency ≈ recovery rate · flask fan-out ≤ MIN of six capacities),
  parameterizable with real numbers, emitting PASS/WARN/FAIL/SKIP with
  reasons — a check with missing parameters is SKIP, never a guessed PASS.
- **Failure-family flags** — composition pattern-matching against the A–T
  breaker taxonomy (unscoped aura → N; trigger engine without cooldown → F;
  proxy compute without authority cost → E/H Hateforge; budget refilled by
  the activity it gates → E; acceptance-minting on rejected drafts →
  "rejections must not pay"; high instruction fidelity without a
  dissent/authority layer → ADAPA_RISK).
- **Verdict** — HOLDS / STRAINS / UNRESOLVED per build.

```python
from semantic_compiler.expansion import decode_build

result = decode_build(
    "verifier: MiniMax M2.5; draft: Qwen draft; supports: MTP K=5, vLLM; "
    "auras: BCC, TokenRouter; flask: auxiliary_i9; anointment: authority_gate",
    params={"draft_rate": 4000, "verifier_acceptance_capacity": 5000},
)
print(result.sheet)     # founder-readable build sheet
print(result.verdict)   # HOLDS | STRAINS | UNRESOLVED
```

Demo: `python scripts/decode_build_demo.py` decodes both dialect examples
plus the COGNITIVE_COSPRI_001 fixture (tuned → HOLDS, overcapped → STRAINS).

## Buildcraft compute ontology

The optional `BUILDCRAFT_COMPUTE_ONTOLOGY` formalizes Path of Exile buildcraft shorthand as guarded structural mappings:

- motherboard/chassis topology → character equipment paper doll
- PCIe accelerator slot → weapon slot
- CPU socket/host position → body-armour slot
- GPU/accelerator → equipped weapon
- CPU package → equipped body armour
- hardware integration capacity → item sockets and links
- LLM/application → active skill gem
- drafter/MTP/cache/framework → support gem
- CUDA/PyTorch/drivers/ABI → compatibility requirements
- occupied VRAM → mana reservation
- deployed architecture → complete build

The registry preserves slot → item → socket/link → component → reservation relationships while rejecting literal material identity. Repositories and packages are classified by deployed function rather than artifact format alone.

Example:

```python
from semantic_compiler.translation import resolve_buildcraft_mappings

mappings = resolve_buildcraft_mappings(
    "PCIe slots are weapon slots; the GPU is the weapon; "
    "the LLM and support gems consume VRAM."
)
```

## Quick start

```bash
# Install (editable) from a fresh clone
pip install -e .

# Run the full suite (core + expansion)
python -m pytest tests -q

# unittest discovery also runs clean (unittest-style subset)
python -m unittest discover

# Generate calibration corpus
python scripts/generate_calibration_corpus.py

# Generate freeze artifacts
python scripts/generate_v2_1_3_freeze_artifacts.py

# Build the V2.2 decompression calibration corpus
python scripts/build_decompression_calibration.py

# Compile a multi-document corpus into an invariant registry
python -c "
from semantic_compiler.expansion.corpus import compile_corpus
report = compile_corpus(['doc1.md', ('doc2', 'raw text', {'evidence_tier': 'PRIMARY_RECORD'})])
print(report['invariant_registry'])
"
```

## Layout

- `core/` — pipeline, types, scoring, audit, dataset export
- `extraction/` — skeleton, relationships, frames, claims, evidence
- `gates/` — semantic gates and repair logic
- `registry/` — terms, cosmological constants, department mappings, buildcraft ontology
- `translation/` — fractal / cross-domain translation and buildcraft shorthand resolution
- `modes/` — operating modes (coherence, reality orientation, defense pathology)
- `expansion/` — V2.2 medical-ontology decompression (templates, pathology, reconstruction, advisor, schema) plus corpus orchestration, evidence tiers, counter-mapping, derivation-order tracking, verdict translation, and the gem_decode executable translation mode
- `schemas/` — JSON Schema for V2.1 dataset rows
- `scripts/` — corpus generation, quarantine, freeze artifacts
- `calibration_output/` — generated corpora, reports, release artifacts
- `tests/` — unit tests

## Release artifacts

| Artifact | Path |
|---|---|
| Release manifest | `calibration_output/RELEASE_MANIFEST_V2_1_3.json` |
| Known limitations | `calibration_output/KNOWN_LIMITATIONS_V2_1_3.md` |
| SFT pilot train | `calibration_output/SFT_PILOT_DATASET_V1.jsonl` |
| SFT pilot eval | `calibration_output/SFT_PILOT_EVALUATION_SET_V1.jsonl` |
| DPO registry | `calibration_output/DPO_DIAGNOSTIC_REGISTRY.json` |
| V2.2 decompression corpus | `calibration_output/decompression_calibration_v2_2.jsonl` |
| V2.2 calibration report | `calibration_output/DECOMPRESSION_CALIBRATION_REPORT_V2_2.md` |
